


MyGame.graphics.renderer = (function () {
	'use strict';

	let canvas = document.getElementById('game');
	let context = canvas.getContext('2d');

	let toWidth = window.innerWidth;
	let toHeight = window.innerHeight;

	canvas.width = toWidth * .95;

	//set the canvas to the size of the window




}());
