'use strict';

MyGame.constants.Direction = Object.freeze({
    Stopped: 'stopped',
    Up: 'up',
    Down: 'down',
    Left: 'left',
    Right: 'right'
});
