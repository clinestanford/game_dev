MyGame.render.background = function (graphics) {
    'use strict';

    graphics.drawSquare({ x: 0, y: 0 }, graphics.width, 'rgb(0, 0, 255)');
};
