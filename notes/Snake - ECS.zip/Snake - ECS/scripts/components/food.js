MyGame.components.Food = function() {
    'use strict';
    let api = {
        get name() { return 'food'; }
    };

    return api;
};
