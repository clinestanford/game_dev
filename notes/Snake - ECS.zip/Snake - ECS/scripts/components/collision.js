MyGame.components.Collision = function() {
    'use strict';
    let api = {
        get name() { return 'collision'; }
    };

    return api;
};
