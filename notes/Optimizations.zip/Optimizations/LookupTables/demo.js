let present = require('present');

const DEGREES_TO_PROCESS = 100000;
const lutSin = preComputeSin();

function preComputeSin() {
    let lutSin = new Array(361);
    for (let degree = 0; degree <= 360; degree++) {
        let radian = degree * (Math.PI / 180);
        lutSin[degree] = Math.sin(radian);
    }

    return lutSin;
}

function lerp(a, b, f) {
    return a + f * (b - a);
}

function processSin() {
    const conversion = Math.PI / 180;

    let total = 0;
    for (let degree = 0; degree <= DEGREES_TO_PROCESS; degree++) {
        total += Math.sin((degree % 360) * conversion);
    }
    return total;
}

function processAnySin() {
    const conversion = Math.PI / 180;

    let total = 0;
    for (let degree = 0; degree <= 360; degree += .01) {
        total += Math.sin(degree * conversion);
    }
    return total;
}

function processSinLUT() {
    let total = 0;
    for (let degree = 0; degree <= DEGREES_TO_PROCESS; degree++) {
        total += lutSin[degree % 360];
    }
    return total;
}

function processAnySinLUT() {
    let total = 0;
    for (let degree = 0; degree <= 360; degree += .01) {
        let value = lerp(lutSin[Math.floor(degree)], lutSin[Math.ceil(degree)], degree % 1);
        total += value;
        // let a = lutSin[Math.floor(degree)];
        // let b = lutSin[Math.ceil(degree)];
        // let f = degree % 1;
        // total += (a + f * (b - a));
    }
    return total;
}

function timeMe(me) {
    let start = present();
    let result = me();
    let end = present();
    console.log('value: ', result);
    return (end - start);
}

console.log('-- processSin --');
console.log('time : ', timeMe(processSin));

console.log();
console.log('-- processSinLUT --');
console.log('time : ', timeMe(processSinLUT));

console.log();
console.log('-- processAnySin --');
console.log('time : ', timeMe(processAnySin));

console.log();
console.log('-- processAnySinLUT --');
console.log('time : ', timeMe(processAnySinLUT));
