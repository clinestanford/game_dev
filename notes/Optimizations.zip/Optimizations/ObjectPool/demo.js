let present = require('present');

const SIM_PARTICLES_COUNT = 10000000;

// ------------------------------------------------------------------
//
// An efficient queue, far more efficient that using an array .shift/.unshift operations
//
// ------------------------------------------------------------------
function Queue(size) {
    let objects = new Array(size);
    let front = 0;
    let back = -1;

    function dequeue() {
        let p = objects[front++];
        front = front % objects.length;

        return p;
    }

    function enqueue(item) {
        back++;
        back = back % objects.length;

        objects[back] = item;
    }

    let api = {
        enqueue: enqueue,
        dequeue: dequeue
    };

    return api;
}

// ------------------------------------------------------------------
//
// Allocate from heap, using by-value parameters.
//
// ------------------------------------------------------------------
function allocateParticle(size, centerX, centerY, direction, speed, rotation, lifetime) {
    return {
        size: size,
        center: { x: centerX, y: centerY },
        direction: direction,
        speed: speed,
        rotation: rotation,
        lifetime: lifetime,
        alive: 0
    };
}

// ------------------------------------------------------------------
//
// Allocate from heap, using by-value of an object.
//
// ------------------------------------------------------------------
function allocateParticle2(spec) {
    return {
        size: spec.size,
        center: { x: spec.centerX, y: spec.centerY },
        direction: spec.direction,
        speed: spec.speed,
        rotation: spec.rotation,
        lifetime: spec.lifetime,
        alive: 0
    };
}

// ------------------------------------------------------------------
//
// Example of an object pool for particles.
//
// ------------------------------------------------------------------
let Pool = (function () {
    let objects = [];
    let front = 0;
    let back = 0;

    function allocateParticle() {
        return {
            size: 0,
            center: { x: 0, y: 0 },
            direction: 0,
            speed: 0,
            rotation: 0,
            lifetime: 0,
            alive: 0
        };
    }

    function allocate(size, centerX, centerY, direction, speed, rotation, lifetime) {
        let p = objects[front++];
        front = front % objects.length;

        p.size = size;
        p.center.x = centerX;
        p.center.y = centerY;
        p.direction = direction;
        p.speed = speed;
        p.rotation = rotation;
        p.lifetime = lifetime;
        p.alive = 0;

        return p;
    }

    function deallocate(p) {
        back++;
        back = back % objects.length;

        objects[back] = p;
    }

    function initialize(initialSize) {
        for (let i = 0; i < initialSize; i++) {
            objects.push(allocateParticle());
        }
    }

    let api = {
        initialize: initialize,
        allocate: allocate,
        deallocate: deallocate
    };

    return api;
}());

// ------------------------------------------------------------------
//
// Demonstrate each of three techniques:
//  1.  Use of object pool
//  2.  Use of heap
//  3.  Use of even more heap
//
// ------------------------------------------------------------------

//
// Use and return a bunch of particles using the object pool
Pool.initialize(5000);
let particles = Queue(5000);
let start = present();
for (let p = 0; p < SIM_PARTICLES_COUNT; p++) {
    particles.enqueue(Pool.allocate(10, 300, 300, 10, 10, 0, 4));
    if (p > 4000) {
        Pool.deallocate(particles.dequeue());
    }
}
let end = present();
console.log('Object Pool Time      : ', end - start);

//
// Use and return a bunch of particles using the heap
particles = Queue(5000);
start = present();
for (let p = 0; p < SIM_PARTICLES_COUNT; p++) {
    particles.enqueue(allocateParticle(10, 300, 300, 10, 10, 0, 4));
    if (p > 4000) {
        particles.dequeue();
    }
}
end = present();
console.log('Heap Pool Time        : ', end - start);

//
// More wasteful use and return a bunch of particles using the heap
particles = Queue(5000);
start = present();
for (let p = 0; p < SIM_PARTICLES_COUNT; p++) {
    particles.enqueue(allocateParticle2({
        size: 10,
        centerX: 300,
        centerY: 300,
        direction: 10,
        speed: 10,
        rotation: 0,
        lifetime: 4
    }));
    if (p > 4000) {
        particles.dequeue();
    }
}
end = present();
console.log('Sloppy Heap Pool Time : ', end - start);
