let present = require('present');

const DEGREES_TO_PROCESS = 1000002;

function processSin(howMany) {
    let total = 0;
    let conversion = Math.PI / 180;
    for (let degree = 0; degree < howMany; degree++) {
        total += Math.sin((degree % 360) * conversion);
    }
    return total;
}

function processSinUnrolled(howMany) {
    const LOOP_UNROLL_SIZE = 5;
    const conversion = Math.PI / 180;

    let total = 0;
    let extra = howMany % LOOP_UNROLL_SIZE;
    for (let degree = 0; degree < howMany - extra; degree += LOOP_UNROLL_SIZE) {
        total += Math.sin(((degree + 0) % 360) * conversion);
        total += Math.sin(((degree + 1) % 360) * conversion);
        total += Math.sin(((degree + 2) % 360) * conversion);
        total += Math.sin(((degree + 3) % 360) * conversion);
        total += Math.sin(((degree + 4) % 360) * conversion);
    }
    if (extra-- > 0) total += Math.sin(((howMany - (extra + 1)) % 360) * conversion);
    if (extra-- > 0) total += Math.sin(((howMany - (extra + 1)) % 360) * conversion);
    if (extra-- > 0) total += Math.sin(((howMany - (extra + 1)) % 360) * conversion);
    if (extra-- > 0) total += Math.sin(((howMany - (extra + 1)) % 360) * conversion);

    return total;
}

function timeMe(me, howMany) {
    let start = present();
    let result = me(howMany);
    let end = present();
    console.log('value: ', result);
    return (end - start);
}

// This is to make sure the JIT compiler can't anticipate the number
// of items to process and do a super loop unroll optimization.
let howMany = Math.random() * DEGREES_TO_PROCESS;

console.log('-- processSin --');
console.log('time : ', timeMe(processSin, howMany));

console.log();
console.log('-- processSinUnrolled --');
console.log('time : ', timeMe(processSinUnrolled, howMany));
