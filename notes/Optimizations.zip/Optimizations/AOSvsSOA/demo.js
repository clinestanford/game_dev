let present = require('present');

const SIM_ITERATIONS = 1;   // Slowly move up by one to show the effect
const SIM_ELAPSED_TIME = 10;    // ms
const SIM_PARTICLES_COUNT = 1000000;

function makeArrayOfStructures(howMany) {
    let particles = [];
    for (let p = 0; p < howMany; p++) {
        particles.push({
            size: Math.random() * 10,
            center: { x: 300, y: 300 },
            direction: { x: Math.random(), y: Math.random() },
            speed: Math.random() * 10,
            rotation: 0,
            lifetime: Math.random() * 4
        })
    }

    return particles;
}

function makeStructureOfArrays(howMany) {
    let particles = {
        size: new Array(howMany),
        centerX: new Array(howMany),
        centerY: new Array(howMany),
        directionX: new Array(howMany),
        directionY: new Array(howMany),
        speed: new Array(howMany),
        rotation: new Array(howMany),
        lifetime: new Array(howMany),
        alive: new Array(howMany),
    };

    for (let p = 0; p < howMany; p++) {
        particles.size[p] = Math.random() * 10;
        particles.centerX[p] = 300;
        particles.centerY[p] = 300;
        particles.directionX[p] = Math.random();
        particles.directionY[p] = Math.random();
        particles.speed[p] = Math.random() * 10;
        particles.rotation[p] = 0;
        particles.lifetime[p] = Math.random() * 4;
    }

    return particles;
}

let particles1 = makeArrayOfStructures(SIM_PARTICLES_COUNT);
let start1 = present();
for (let iter = 0; iter < SIM_ITERATIONS; iter++) {
    for (let p = 0; p < SIM_PARTICLES_COUNT; p++) {
        particles1[p].center.x += (SIM_ELAPSED_TIME * particles1[p].speed * particles1[p].direction.x);
        particles1[p].center.y += (SIM_ELAPSED_TIME * particles1[p].speed * particles1[p].direction.y);
        particles1[p].alive += SIM_ELAPSED_TIME;
    }
}
let end1 = present();
console.log('Array of structures : ', end1 - start1);


let particles2 = makeStructureOfArrays(SIM_PARTICLES_COUNT);
let start2 = present();
for (let iter = 0; iter < SIM_ITERATIONS; iter++) {
    for (let p = 0; p < SIM_PARTICLES_COUNT; p++) {
        particles2.centerX[p] += (SIM_ELAPSED_TIME * particles2.speed[p] * particles2.directionX[p]);
        particles2.centerY[p] += (SIM_ELAPSED_TIME * particles2.speed[p] * particles2.directionY[p]);
        particles2.alive[p] += SIM_ELAPSED_TIME;
    }
}
let end2 = present();
console.log('Structure of Arrays : ', end2 - start2);

//
// Be sure to swap the order of these to show the effect on performance
