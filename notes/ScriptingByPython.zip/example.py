#
# Simple script that demonstrates how to script elements of the game engine.

# This imports the C++ executable library
from build.Debug import ScriptingExample

totalTime = 0
gameDone = False

#
# An example function passed to the game engine, which the game engine
# then invokes for each 'Meanie' currently in the game during the update cycle.
#
def moveMeanie(elapsedTime, meanie):
    meanie.positionX = meanie.positionX + meanie.speedX
    meanie.positionY = meanie.positionY + meanie.speedY

#
# An example function passed to the game engine that is invoked once per
# game engine update cycle.  This gives an opportunity for the script to do
# any additional game updates necessary.
#
def updateGame(elapsedTime):
    global totalTime
    global gameDone
    totalTime = totalTime + elapsedTime
    if totalTime > 100:
        gameDone = True

#
# Create a GameModel object from the game engine
#
gameModel = ScriptingExample.GameModel(updateGame)

#
# Demonstates creating a Meanie object using both the createMeanie factory
# function from the game engine and directly from the Meanie data type.
#
def initializeGame():
    gameModel.createMeanie("Ogre", 0.0, 0.0, 1.0, 0.0, moveMeanie)
    myMeanie = ScriptingExample.Meanie("Troll", 0.0, 0.0, 0.0, 1.0, moveMeanie)
    gameModel.addMeanie(myMeanie)

#
# Get the game loop going and stay in it until the script decides it should terminate
#
initializeGame()
while gameDone == False:
    gameModel.pulse()

print('finished')
