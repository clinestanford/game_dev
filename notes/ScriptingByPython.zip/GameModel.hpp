#pragma once
#include <chrono>
#include <functional>
#include <vector>
#include <memory>

#include "Meanie.hpp"

// ------------------------------------------------------------------
//
// The GameModel is a combination of the game engine and game model.
// Ideally wouldn't do this in an actual project, because the purpose
// of this example is demonstrating how to integrate scripting, it
// is fine.
//
// This class has responsibility for maintaining the execution of the
// standard game loop.  This also includes management of the elapsed time,
// making it available to the script which drives the engine.
//
// ------------------------------------------------------------------
class GameModel
{
public:
	GameModel(std::function<void(long)> update):
		m_updateScript(update),
		m_previousTime(std::chrono::high_resolution_clock::now())
	{
	}

	void pulse();
	std::shared_ptr<Meanie> createMeanie(std::string name, double x, double y, double speedX, double speedY, std::function<void(long, Meanie*)> move);
	void addMeanie(std::shared_ptr<Meanie> meanie);

private:
	std::function<void(long)> m_updateScript;
	std::chrono::time_point<std::chrono::high_resolution_clock> m_previousTime;
	std::vector<std::shared_ptr<Meanie>> m_meanies;

	void update(std::chrono::milliseconds elapsedTime);
	void render(std::chrono::milliseconds elapsedTime);

};
