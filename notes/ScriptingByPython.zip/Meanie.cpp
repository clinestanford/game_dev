#include "Meanie.hpp"
#include <iostream>
#include <string>

Meanie::Meanie(std::string name, double x, double y, double sx, double sy, std::function<void (long, Meanie*)> move):
	m_name(name),
	m_positionX(x),
	m_positionY(y),
	m_speedX(sx),
	m_speedY(sy),
	moveScript(move)
{
}

// ------------------------------------------------------------------
//
// Invoke the function passed in through the constructor.  That function
// is responsible for moving the Meanie instance.
//
// ------------------------------------------------------------------
void Meanie::move(long elapsedTime)
{
	moveScript(elapsedTime, this);
}

// ------------------------------------------------------------------
//
// Report the state of the Meanie to the console.
//
// ------------------------------------------------------------------
void Meanie::render()
{
	std::cout << "Meanie: " << m_name << " ";
	std::cout << "position: (" << m_positionX << ", " << m_positionY << ") ";
	std::cout << "speed: (" << m_speedX << ", " << m_speedY << ")";
	std::cout << std::endl;
}
