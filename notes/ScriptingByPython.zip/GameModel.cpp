#include "GameModel.hpp"
#include <iostream>
#include <thread>

// ------------------------------------------------------------------
//
// Advance the game loop, also maintain the elapsed time.
//
// ------------------------------------------------------------------
void GameModel::pulse()
{
	std::chrono::time_point<std::chrono::high_resolution_clock> currentTime = std::chrono::high_resolution_clock::now();
	std::chrono::milliseconds elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - m_previousTime);
	m_previousTime = currentTime;

	update(elapsedTime);
	render(elapsedTime);
}

// ------------------------------------------------------------------
//
// Example factory method that demonstrates using C++ code to create
// a Meanie type and add it to the list of meanies in the game.
//
// ------------------------------------------------------------------
std::shared_ptr<Meanie> GameModel::createMeanie(std::string name, double x, double y, double speedX, double speedY, std::function<void(long, Meanie*)> move)
{
	auto meanie = std::make_shared<Meanie>(name, x, y, speedX, speedY, move);
	m_meanies.push_back(meanie);

	return meanie;
}

// ------------------------------------------------------------------
//
// Example method through which the script can add a new Meanie to
// the game model.
//
// ------------------------------------------------------------------
void GameModel::addMeanie(std::shared_ptr<Meanie> meanie)
{
	m_meanies.push_back(meanie);
}

// ------------------------------------------------------------------
//
// Standard game loop update method.  If the script has provided an
// update function to invoke, it is utilized.
//
// ------------------------------------------------------------------
void GameModel::update(std::chrono::milliseconds elapsedTime)
{
	if (m_updateScript)
	{
		m_updateScript(static_cast<long>(elapsedTime.count()));
	}
	for (auto&& meanie : m_meanies)
	{
		meanie->move(static_cast<long>(elapsedTime.count()));
	}
	std::this_thread::sleep_for(std::chrono::milliseconds(20));
}

// ------------------------------------------------------------------
//
// Standard game loop render method.  All the Meanies in the game
// are asked to render themselves.
//
// ------------------------------------------------------------------
void GameModel::render(std::chrono::milliseconds elapsedTime)
{
	std::cout << "rendering..." << std::endl << std::endl;
	for (auto&& meanie : m_meanies)
	{
		meanie->render();
	}
	std::cout << std::endl;
}
