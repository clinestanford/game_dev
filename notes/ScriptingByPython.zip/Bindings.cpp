#include "pybind11/pybind11.h"
#include "pybind11/functional.h"
#include "Meanie.hpp"
#include "GameModel.hpp"

namespace py = pybind11;

// ------------------------------------------------------------------
//
// Demonstration for how to expose certain data types or other
// elements of the game engine to the Python code.  Two things are
// exposed in this example, the GameModel and the Meanie type.
//
// ------------------------------------------------------------------
PYBIND11_MODULE(ScriptingExample, m)
{
	// ------------------------------------------------------------------
	//
	// Only expose the public methods needed by the Python script, in 
	// particular the 'pulse' method which advances the game loop.
	//
	// ------------------------------------------------------------------
	py::class_<GameModel>(m, "GameModel")
		.def(py::init<std::function<void(long)>>())
		.def("pulse", &GameModel::pulse)
		.def("createMeanie", &GameModel::createMeanie)
		.def("addMeanie", &GameModel::addMeanie)
		;

	// ------------------------------------------------------------------
	//
	// Demonstration of how to expose both methods and properties
	//
	// ------------------------------------------------------------------
	py::class_<Meanie, std::shared_ptr<Meanie>>(m, "Meanie")
		.def(py::init<std::string, double, double, double, double, std::function<void (long, Meanie*)>>())
		.def("move", &Meanie::move)
		.def_property("positionX", &Meanie::getPositionX, &Meanie::setPositionX)
		.def_property("positionY", &Meanie::getPositionY, &Meanie::setPositionY)
		.def_property_readonly("speedX", &Meanie::getSpeedX)
		.def_property_readonly("speedY", &Meanie::getSpeedY)
		;
}
