#pragma once
#include <functional>
#include <string>

// ------------------------------------------------------------------
//
// The purpose of this class is as a demonstration for how to expose
// a C++ data type to the Python scripting code.  Nothing special has
// to be done with this class, all the magic happens in the Bindings.cpp file.
//
// The constructor for this class accepts a function that is invoked
// whenever the Meanie is moved.  This could be a C++ function if
// the game is being scripted using C++, but it can also be a Python
// function, which is cool.
//
// ------------------------------------------------------------------
class Meanie
{
public:
	Meanie(std::string name, double x, double y, double sx, double sy, std::function<void (long, Meanie*)> move);

	void move(long elapsedTime);

	void setPositionX(double x) { m_positionX = x; }
	double getPositionX() { return m_positionX; }

	void setPositionY(double y) { m_positionY = y; }
	double getPositionY() { return m_positionY; }

	double getSpeedX() { return m_speedX; }
	double getSpeedY() { return m_speedY; }

	void render();

private:
	std::string m_name;
	double m_positionX;
	double m_positionY;
	double m_speedX;
	double m_speedY;

	std::function<void(long, Meanie*)> moveScript;
};
